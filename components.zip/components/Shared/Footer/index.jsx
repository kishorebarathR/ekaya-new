import React from 'react'
import Footerpage from './Footerpage'

const index = () => {
  return (
    <Footerpage /> 
  )
}

export default index