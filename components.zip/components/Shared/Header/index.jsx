
import React from 'react'
import { Row,Col, Container } from 'react-bootstrap'
import Headerpage from './Headerpage'


const index = () => {
  return (
    <>

            <Headerpage />
           
   
    </>
  )
}

export default index