import React from 'react'

import Header from '../Shared/Header'
import Footer from '../Shared/Footer'
import AboutBanner from './AboutBanner'
import OurStory from './OurStory'
const index = () => {
  return (
    <>
      <Header />
            <AboutBanner />
            <OurStory />
           
         
    <Footer />
    </>
  )
}

export default index