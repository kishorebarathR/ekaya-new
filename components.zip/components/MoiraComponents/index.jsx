import React from 'react'
import Header from '../Shared/Header'
import Footer from '../Shared/Footer'
import MoiraBanner from './MoiraBanner'
import MoiraPage from './MoiraPage'



const index = () => {
  return (
    <>
    <Header />
            <MoiraBanner />
          <MoiraPage />
            
          
         
    <Footer />
    </>
  )
}

export default index